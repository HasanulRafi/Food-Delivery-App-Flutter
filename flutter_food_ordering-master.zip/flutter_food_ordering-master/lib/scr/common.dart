import 'package:flutter/material.dart';

const white = Colors.white;
const red = Colors.red;
const black = Colors.black;
const grey = Colors.grey;